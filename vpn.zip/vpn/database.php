<?php
$host = 'localhost'; // Host name (normally 'localhost')
$username = 'wattspor'; // MySQL login username
$password = 'wattball10'; // MySQL login password
$database = 'wattspor_database'; // Database name#

mysql_connect($host, $username, $password);
mysql_select_db($database);
?>