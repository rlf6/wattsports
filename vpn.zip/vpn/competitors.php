<?php
error_reporting(E_ALL); 
ini_set('display_errors', 1);

include("../database.php");

$active1 ='';
$active2 ='';
$active3 ='active';
$active4 ='';
$active5 ='';
$active6 ='';
 $Title = "Wattsports";
$mobile ='';

include('./header.php');



?>


<div class="center_div" border="2px solid">
	<div class="scroll_h">

	
<p><a href="wattballdetails.php"><img class="left" src="http://www.wattsports.co.uk/wp-content/themes/canvas/images/football_tournament.png" title="Edit WattBall Teams Details" alt="Register your WattBall Team" width="300" height="200" /></a>&nbsp;	&nbsp;	&nbsp;	<a href="./hurdlerdetails.php"><img class="right" src="http://www.wattsports.co.uk/wp-content/themes/canvas/images/hurdles_tournament.png" width="300" height="200" title="Edit Hurdlers details" alt="Register Hurdler"  /></a></p>

	</div>				
</div>

</div>
</html>

