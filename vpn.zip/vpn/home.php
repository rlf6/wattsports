<?php
error_reporting(E_ALL); 
ini_set('display_errors', 1);

include("../database.php");

$active1 ='active';
$active2 ='';
$active3 ='';
$active4 ='';
$active5 ='';
$active6 ='';
 $Title = "Wattsports";
$mobile ='';
include('./header.php');
?>

<div class="center_div" border="2px solid">
				
				
			<div class="scroll">

	
			<p> 
			Latest News: <br />
			Minimum Required Teams for tournament = 16 now instead of 20<br />
			Tickets Report now Daily instead of Weekly<br />
			Software Update Due: 25/06/2012<br />
			<br />
			Needing Attention:<br />
			Issues to be dealt with see Tabs to the right.<br />
			</p>
			<a href="http://www.wattsports.co.uk" />Wattsports</a>
			
 			</div>
			
			
			<table class="success" >
			
			</table>
			</div>
						
</div>

</div>
</html>